const express = require("express");
const path = require("path");
const cors = require('cors');
const morgan = require('morgan');
const fs = require('fs');
const rfs = require('rotating-file-stream');

const router = require("./router");

const startServer = async () => {
  const BASEDIR = process.env.BASEDIR || path.resolve(".");
  const LOGDIR = process.env.LOGDIR|| path.join(BASEDIR, '/log')
  const PORT = process.env.PORT || 8080;

  const app = express();

  //cors 설정
  app.use(cors());

  //로깅
  fs.existsSync(LOGDIR) || fs.mkdirSync(LOGDIR)
  const accessLogStream = rfs.createStream('access.log', {
    interval: '1d', // 매일 매일 로그 파일 생성
    path: LOGDIR
  })
  app.use(morgan('combined', {stream: accessLogStream}))

  app.use(express.static(BASEDIR + "/public"));
  app.set("views", BASEDIR + "/views");
  app.set("view engine", "ejs");
  app.engine("html", require("ejs").renderFile);
  app.use(express.json());
  app.use(
    express.urlencoded({
      extended: true,
    })
  );

  //no cache 설정
  app.use(function (req, res, next) {
    res.header('Cache-Control', 
         'private, no-cache, no-store, must-revalidate');
    res.header('Expires', '-1');
    res.header('Pragma', 'no-cache');
    next()
  });


  app.use(router);
  app.listen(PORT, () => {
    console.log(`#### ${PORT} 에서 서버가 시작되었습니다`);
  });
};

startServer();
