import PropTypes from 'prop-types';
import { useDelete, usePut } from './hooks/useAxios';

const TodoItem = ({ todoItem, fetchData, owner }) => {
    const { deleteData } =useDelete({ timeout: 10000 });
    const { putData } =usePut({ timeout: 10000 });

    const toggleItem = (id) => {
        putData(`/todolist/${owner}/${id}/completed`, { }, ()=> {
            fetchData(`/todolist/${owner}`);
        })
    }
    
    const deleteItem = (id) => {
        deleteData(`/todolist/${owner}/${id}`, ()=> {
            fetchData(`/todolist/${owner}`);
        })
    }

    return (
        <li key={todoItem.id}>
            {todoItem.todo} : {todoItem.desc}
            {" "}
            <button onClick={()=>toggleItem(todoItem.id)}>{todoItem.completed ? "완료" : "미완료"}</button>
            {" "}
            <button onClick={()=>deleteItem(todoItem.id)}>삭제</button>
        </li>
    );
};

TodoItem.propTypes = {
    todoItem: PropTypes.shape({
        id: PropTypes.string.isRequired,
        todo: PropTypes.string.isRequired,
        desc: PropTypes.string.isRequired,
        completed: PropTypes.bool.isRequired,
    }),
    owner: PropTypes.string.isRequired,
    fetchData: PropTypes.func.isRequired,
};

export default TodoItem;