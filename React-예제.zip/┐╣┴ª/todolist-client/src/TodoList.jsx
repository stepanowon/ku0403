import { useEffect } from "react";
import { useFetch } from "./hooks/useAxios";
import PropTypes from 'prop-types';
import TodoItem from "./TodoItem";

const TodoList = ({ owner }) => {

  const { response, isLoading, error, fetchData } = useFetch({ timeout: 10000 });

  useEffect(()=>{
    fetchData(`/todolist/${owner}`);
  }, [])

  return (
    <div>
      <ul>
        {error ? (
          <h3>에러 발생 : {error.message}</h3>
        ) : response && response.data.status === "success" ? (
          response.data.todolist.map((item) => {
            return (
                <TodoItem key={item.id} todoItem={item} fetchData={fetchData} owner={owner} />
            );
          })
        ) : (
          ""
        )}
      </ul>
      {isLoading ? <h3>조회중</h3> : ""}
    </div>
  );
};

TodoList.propTypes = {
    owner: PropTypes.string.isRequired,    
};

export default TodoList;
 
