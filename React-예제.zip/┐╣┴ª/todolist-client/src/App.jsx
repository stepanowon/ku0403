import TodoList from "./TodoList"
import AddTodo from "./AddTodo"
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import { useState } from "react";

const App = () => {
  const [owner, setOwner] = useState("mrlee");
  return (
    <div>
      <Router>
        <h2> Custom Hook을 이용한 HTTP 요청 예제</h2>
        <hr />
        <div>
          사용자 변경 : <input type="text" value={owner} onChange={(e)=>setOwner(e.target.value)} />
        </div>
        <hr />
        <Link to="/">할일 목록</Link>&nbsp;
        <Link to="/add">할일 추가</Link>
        <hr />
        <Routes>
          <Route path="/" element={<TodoList owner={owner} />} />
          <Route path="/add" element={<AddTodo owner={owner} />} />
        </Routes>
      </Router>
    </div>
  )
}

export default App
