import { useState } from "react";
import { usePost } from "./hooks/useAxios";
import { useNavigate } from "react-router";
import PropTypes from 'prop-types';

const AddTodo = ({ owner }) => {
  const [todo, setTodo] = useState("");
  const [desc, setDesc] = useState("");
  const navigate=  useNavigate();

  const { response, isProcessing, error, postData } = usePost({ timeout: 10000 });

  const addTodoHandler = () => {
    if (!todo || todo.length < 2 || !desc) {
      alert("할일(todo)은 두글자 이상, 설명(desc)는 반드시 입력해주세요.");
      return;
    }
    const data = { todo, desc };
    postData(`/todolist/${owner}`, data, ()=> {
      navigate("/");
    });
  };

  return (
    <div>
      할일 :{" "}
      <input type="text" value={todo} onChange={(e)=>setTodo(e.target.value)} />
      <br />
      설명 :{" "}
      <input type="text" value={desc} onChange={(e)=>setDesc(e.target.value)} />
      <br /><br />
      <button onClick={addTodoHandler}>할일 추가</button>
      <br />
      { error ? (
        <h3>에러 발생 : {error.message}</h3>
      ) : response ? (
        <h3>{response.data.message}</h3>
      ) : (
        ""
      )}
      {isProcessing ? <h3>처리중</h3> : ""}
    </div>
  );
};

AddTodo.propTypes = {
    owner: PropTypes.string.isRequired,    
};

export default AddTodo;
