import axios from "axios";
import { useState } from "react";

axios.defaults.baseURL = "http://localhost:8080";

const useFetch = (params) => {
    const [response, setResponse] = useState();
    const [error, setError] = useState();
    const [isLoading, setIsLoading] = useState(false);
  
    const fetchData = async (url) => {
      setResponse(undefined);
      setError(undefined);
      setIsLoading(true);
      try {
        const result = await axios.get(url, params);
        setResponse(result);
      } catch (err) {
        setError(err);
      } finally {
        setIsLoading(false);
      }
    };
  
    return { response, error, isLoading, fetchData };
};

const usePost = (params) => {
    const [response, setResponse] = useState();
    const [error, setError] = useState();
    const [isProcessing, setIsProcessing] = useState(false);
  
    const postData = async (url, data, callback) => {
      setResponse(undefined);
      setError(undefined);
      setIsProcessing(true);
      try {
        const result = await axios.post(url, data, params);
        setResponse(result);
      } catch (err) {
        setError(err);
      } finally {
        setIsProcessing(false);
        callback();
        setTimeout(()=>{
          setResponse(undefined);
          setError(undefined);
        }, 3000);
      }
    };
  
    return { response, error, isProcessing, postData };
};

const usePut = (params) => {
    const [response, setResponse] = useState();
    const [error, setError] = useState();
    const [isProcessing, setIsProcessing] = useState(false);
  
    const putData = async (url, data, callback) => {
      setResponse(undefined);
      setError(undefined);
      setIsProcessing(true);
      try {
        const result = await axios.put(url, data, params);
        setResponse(result);
      } catch (err) {
        setError(err);
      } finally {
        setIsProcessing(false);
        callback();
        setTimeout(()=>{
          setResponse(undefined);
          setError(undefined);
        }, 3000);
      }
    };
  
    return { response, error, isProcessing, putData };
};

const useDelete = (params) => {
    const [response, setResponse] = useState();
    const [error, setError] = useState();
    const [isProcessing, setIsProcessing] = useState(false);
  
    const deleteData = async (url, callback) => {
      setResponse(undefined);
      setError(undefined);
      setIsProcessing(true);
      try {
        const result = await axios.delete(url, params);
        setResponse(result);
      } catch (err) {
        setError(err);
      } finally {
        setIsProcessing(false);
        callback();
        setTimeout(()=>{
          setResponse(undefined);
          setError(undefined);
        }, 3000);
      }
    };
  
    return { response, error, isProcessing, deleteData };
};

export { useFetch, usePost, usePut, useDelete };
