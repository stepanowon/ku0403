import React from 'react';
import axios from 'axios'

const requestAPI = () => {
  const url = "http://localhost:8080/todolist/gdhong";
  axios.get(url).then((response) => {
     console.log("# 응답 객체 : ", response);
  });
};
requestAPI();

const App = () => {
  return (
    <div>
      <h3>Console Log를 확인하세요</h3>
    </div>
  );
};

export default App;