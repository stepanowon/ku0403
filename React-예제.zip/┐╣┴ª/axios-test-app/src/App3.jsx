//App3.jsx
import axios from "axios";

const listUrl = "http://localhost:8080/todolist/gdhong";
const todoUrlPrefix = "http://localhost:8080/todolist/gdhong/";

//4건의 목록을 조회한 후 한건씩 순차적으로 순회하며 조회하기
const requestAPI = async () => {
  let todoList;

  try {
    let response = await axios.get(listUrl);
    todoList = response.data.todolist;
    console.log("# TodoList : ", todoList);
    for (let i = 0; i < todoList.length; i++) {
      response = await axios.get(todoUrlPrefix + todoList[i].id);
      console.log(`# ${i + 1}번째 Todo : `, response.data);
    }
  } catch (e) {
    if (e instanceof Error) console.log(e.message);
    else console.log(e);
  }
};

requestAPI();

const App = (props) => {
  return <h2>Console.log를 확인하세요</h2>;
};

export default App;
