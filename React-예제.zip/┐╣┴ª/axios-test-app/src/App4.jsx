//App4.jsx
import axios from "axios";

const requestAPI = async () => {
  const url = "http://localhost:8080/todolist/gdhong";
  const response = await axios.get(url);
  console.log("# 응답객체 : ", response);
};
requestAPI();

const App4 = () => {
  return <h2>Console Log를 확인합니다.</h2>;
};

export default App4;
